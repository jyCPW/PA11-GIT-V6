﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Restartbtn : MonoBehaviour
{
    public Button restartbtn;
    // Start is called before the first frame update
    void Start()
    {
        Button rtsbtn = restartbtn.GetComponent<Button>();
        rtsbtn.onClick.AddListener(Restartgame);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Restartgame()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
