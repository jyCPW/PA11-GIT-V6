﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed;
    public float score = 0;
    public Text Scoretxt;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        float verticalInput = Input.GetAxis("Vertical");
      
        transform.position = transform.position + new Vector3(0 , verticalInput * speed * Time.deltaTime, 0);
        float ClampY = Mathf.Clamp(transform.position.y, -3.9f, 3.9f);
        transform.position = new Vector3(-8.5f, ClampY, 0);


    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Obstacle")
        {
            SceneManager.LoadScene("Gameoverscene");
        }
        if(other.tag == "Score")
        {
            score++;
            Scoretxt.text = "Score : " + score;
        }
    }
}
